//[Skin Customization]
webix.skin.material.js.skin=//[Skin Customization]
webix.skin.material.barHeight=45;webix.skin.material.tabbarHeight=47;webix.skin.material.rowHeight=38;webix.skin.material.listItemHeight=34;webix.skin.material.inputHeight=38;webix.skin.material.layoutMargin.wide=10;webix.skin.material.layoutMargin.space=10;webix.skin.material.layoutPadding.space=10;
 webix.skin.set('material');webix.skin.material.barHeight=32;webix.skin.material.tabbarHeight=16;webix.skin.material.rowHeight=16;webix.skin.material.listItemHeight=16;webix.skin.material.inputHeight=16;webix.skin.material.layoutMargin.wide=10;webix.skin.material.layoutMargin.space=1;webix.skin.material.layoutPadding.space=2;
 webix.skin.set('material')